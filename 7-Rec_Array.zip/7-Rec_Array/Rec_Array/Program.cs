﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Rec_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[, ,] a = new int[3, 3, 3];
            a[0,0,0]=10;
            a[0,0,1]=51;
            a[0,0,2]=42;
            a[0,1,0]=93;
            a[0,1,1]=34;
            a[0,1,2]=25;

            foreach (int i in a)
            {
                Console.Write(i+" ");
            }
            Console.Read();
        }
    }
}
