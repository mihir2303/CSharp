﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1D_array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[]a=new int[3];
            a[0]=23;
            a[1]=03;
            a[2]=05;

            foreach (int i in a)
            {
                Console.WriteLine(i);
            }
            Console.Read();
        }
    }
}
