﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace loop
{
    class Program
    {
        static void Main(string[] args)
        {
            //1 2 3 6 18 108.... n

            //do while loop
            Console.Write("Enter Any Number:");
            int n = Convert.ToInt32(Console.ReadLine());
            int i = 1, old = 2, New = 3;
             do
             {
                 if(i<=3)
                 {
                     Console.Write(i+" ");
                     i++;
                 }
                 else
                 {
                     i=old*New;
                     if(i>=n)
                     {
                         break;
                     }
                     Console.Write(i+" ");
                     old=New;
                     New=i;
                 }
             }while(i<=n);
             Console.Read();

            //for loop
           /*int i,a=1,b;
            for(i=1;i<=n;i++)
            {
                 Console.Write(" "+a);
                a=b;
                b=a*b;
            }
                Console.Read();*/
            

            //while loop
            /*int i = 1, a = 1, b;
            while (i <= n)
            {
                Console.Write(" " + a);
                a = b;
                b = a * b;
                i++;
            }
            Console.Read();*/
        }
    }
}
